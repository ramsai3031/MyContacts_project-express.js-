const express=require("express");
const router=express.Router();
const {getContact,updateContact,getContacts,createContact,deleteContact}=require("./controllers/contactControllers");
const ValidateToken = require("./controllers/middleware/validateTokenHandler");


router.use(ValidateToken)
router.route("/").get(getContact).post(createContact)

router.route("/:id").get(getContacts).put(updateContact).delete(deleteContact)

module.exports=router;